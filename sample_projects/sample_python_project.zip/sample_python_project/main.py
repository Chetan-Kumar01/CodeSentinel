from utils import greet

greet("Chetan")

print("Hello World")